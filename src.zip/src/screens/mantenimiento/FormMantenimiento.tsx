import { useEffect } from 'react';
import { View, Text, TextInput, ScrollView, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { StackScreenProps } from '@react-navigation/stack';
import { StackMantenimientoParams } from '../../navigator/MantenimientoStackNavigator';
import { useMantenimientoForm } from '../../hooks/useMantenimientoForm';
import { BtnTouch } from '../../components/BtnTouch';
import { ImagenPicker } from '../../components/ImagenPicker';
import {
  colorEstado,
  colorPrioridad,
  siguienteEstadoMan,
  siguientePrioridad,
} from '../../interfaces/mantenimientoResponse';

interface Props extends StackScreenProps<StackMantenimientoParams, 'FormMantenimiento'> {}

export const FormMantenimiento = ({ route, navigation }: Props) => {
  const {
    state,
    setAll,
    handleInputChange,
    handleSubmit,
    handleDelete,
    handleCambiarEstado,
    handleCambiarPrioridad,
  } = useMantenimientoForm();

  useEffect(() => {
    setAll({ ...route.params, fecha: String(route.params.fecha).slice(0, 10) });
  }, []);

  const isEditing = state.id_in !== 0;

  const guardar = async () => {
    const faltan = !state.equipo.trim() || !state.solicitante.trim() || !state.descripcion.trim();
    if (faltan) {
      Alert.alert('Faltan datos', 'Escribe el equipo, quién solicita y la descripción del problema.');
      return;
    }
    (await handleSubmit()) && navigation.popToTop();
  };

  const eliminar = () => {
    Alert.alert('Eliminar solicitud', '¿Seguro que quieres eliminarla? No se puede deshacer.', [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Eliminar',
        style: 'destructive',
        onPress: async () => {
          (await handleDelete()) && navigation.popToTop();
        },
      },
    ]);
  };

  const colorDelEstado = colorEstado[state.estado];
  const colorDePrioridad = colorPrioridad[state.prioridad];

  return (
    <View style={styles.mainContainer}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.headerRow}>
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={() => navigation.popToTop()}
            style={styles.backButton}
          >
            <Text style={styles.backButtonText}>←</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>
            {isEditing ? 'Editar solicitud' : 'Nueva solicitud'}
          </Text>
        </View>

        {/* Estado y prioridad: se cambian con botón */}
        <View style={styles.statusCard}>
          {isEditing && (
            <View style={styles.statusBlock}>
              <View style={styles.statusInfo}>
                <Text style={styles.statusLabel}>Estado</Text>
                <View style={styles.statusValueRow}>
                  <View style={[styles.dot, { backgroundColor: colorDelEstado }]} />
                  <Text style={styles.statusValue}>{state.estado}</Text>
                </View>
              </View>
              <TouchableOpacity
                activeOpacity={0.8}
                onPress={() => handleCambiarEstado(siguienteEstadoMan(state.estado))}
                style={[styles.statusButton, { backgroundColor: colorEstado[siguienteEstadoMan(state.estado)] }]}
              >
                <Text style={styles.statusButtonText}>
                  Pasar a {siguienteEstadoMan(state.estado)}
                </Text>
              </TouchableOpacity>
            </View>
          )}

          <View style={[styles.statusBlock, isEditing && styles.statusBlockBorder]}>
            <View style={styles.statusInfo}>
              <Text style={styles.statusLabel}>Prioridad</Text>
              <View style={styles.statusValueRow}>
                <View style={[styles.dot, { backgroundColor: colorDePrioridad }]} />
                <Text style={styles.statusValue}>{state.prioridad}</Text>
              </View>
            </View>
            <TouchableOpacity
              activeOpacity={0.8}
              onPress={() => handleCambiarPrioridad(siguientePrioridad(state.prioridad))}
              style={[styles.statusButton, { backgroundColor: colorPrioridad[siguientePrioridad(state.prioridad)] }]}
            >
              <Text style={styles.statusButtonText}>
                Cambiar a {siguientePrioridad(state.prioridad)}
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Equipo y problema</Text>

          <Text style={styles.inputLabel}>Equipo</Text>
          <TextInput
            style={styles.input}
            value={state.equipo}
            onChangeText={(text) => handleInputChange('equipo', text)}
            placeholder="Ej. Compresor de aire"
            placeholderTextColor="#9AA8B6"
          />

          <Text style={styles.inputLabel}>Tipo de mantenimiento</Text>
          <TextInput
            style={styles.input}
            value={state.tipo_mantenimiento}
            onChangeText={(text) => handleInputChange('tipo_mantenimiento', text)}
            placeholder="Preventivo, correctivo..."
            placeholderTextColor="#9AA8B6"
          />

          <Text style={styles.inputLabel}>Descripción</Text>
          <TextInput
            style={[styles.input, styles.textArea]}
            value={state.descripcion}
            onChangeText={(text) => handleInputChange('descripcion', text)}
            placeholder="¿Qué le pasa al equipo?"
            placeholderTextColor="#9AA8B6"
            multiline
            numberOfLines={3}
          />

          <Text style={[styles.sectionTitle, styles.sectionGap]}>Dónde y quién</Text>

          <View style={styles.row}>
            <View style={styles.flexItem}>
              <Text style={styles.inputLabel}>Área</Text>
              <TextInput
                style={styles.input}
                value={state.area}
                onChangeText={(text) => handleInputChange('area', text)}
                placeholder="Área"
                placeholderTextColor="#9AA8B6"
              />
            </View>
            <View style={styles.flexItem}>
              <Text style={styles.inputLabel}>Ubicación</Text>
              <TextInput
                style={styles.input}
                value={state.ubicacion}
                onChangeText={(text) => handleInputChange('ubicacion', text)}
                placeholder="Ubicación"
                placeholderTextColor="#9AA8B6"
              />
            </View>
          </View>

          <Text style={styles.inputLabel}>Solicitante</Text>
          <TextInput
            style={styles.input}
            value={state.solicitante}
            onChangeText={(text) => handleInputChange('solicitante', text)}
            placeholder="Quién pide el mantenimiento"
            placeholderTextColor="#9AA8B6"
          />

          <View style={styles.row}>
            <View style={styles.flexItem}>
              <Text style={styles.inputLabel}>Fecha</Text>
              <TextInput
                style={styles.input}
                value={state.fecha}
                onChangeText={(text) => handleInputChange('fecha', text)}
                placeholder="AAAA-MM-DD"
                placeholderTextColor="#9AA8B6"
                keyboardType="numbers-and-punctuation"
                maxLength={10}
              />
            </View>
            <View style={styles.flexItem}>
              <Text style={styles.inputLabel}>Técnico</Text>
              <TextInput
                style={styles.input}
                value={state.tecnico}
                onChangeText={(text) => handleInputChange('tecnico', text)}
                placeholder="Asignado a"
                placeholderTextColor="#9AA8B6"
              />
            </View>
          </View>

          <Text style={styles.inputLabel}>Observaciones</Text>
          <TextInput
            style={[styles.input, styles.textArea]}
            value={state.observaciones}
            onChangeText={(text) => handleInputChange('observaciones', text)}
            placeholder="Notas del técnico, piezas usadas..."
            placeholderTextColor="#9AA8B6"
            multiline
            numberOfLines={3}
          />

          <Text style={[styles.sectionTitle, styles.sectionGap]}>Fotos</Text>
          <View style={styles.photoGrid}>
            <ImagenPicker label="Foto 1" value={state.imagen1} onChange={(v) => handleInputChange('imagen1', v)} />
            <ImagenPicker label="Foto 2" value={state.imagen2} onChange={(v) => handleInputChange('imagen2', v)} />
            <ImagenPicker label="Foto 3" value={state.imagen3} onChange={(v) => handleInputChange('imagen3', v)} />
            <ImagenPicker label="Foto 4" value={state.imagen4} onChange={(v) => handleInputChange('imagen4', v)} />
          </View>

          <View style={styles.actionsContainer}>
            <BtnTouch
              text={isEditing ? 'Guardar' : 'Crear'}
              color="#E8A317"
              borderColor="transparent"
              onPress={guardar}
            />
            {isEditing && (
              <BtnTouch
                text="Eliminar"
                color="#D9534F"
                borderColor="transparent"
                onPress={eliminar}
              />
            )}
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    backgroundColor: '#18222C',
  },
  scrollContent: {
    paddingHorizontal: 16,
    paddingTop: 48,
    paddingBottom: 40,
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  backButton: {
    position: 'absolute',
    left: 0,
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#243342',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButtonText: {
    color: '#EAF0F6',
    fontSize: 18,
    fontWeight: 'bold',
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: '800',
    color: '#EAF0F6',
  },
  statusCard: {
    backgroundColor: '#243342',
    borderRadius: 16,
    paddingHorizontal: 16,
    marginBottom: 14,
  },
  statusBlock: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
  },
  statusBlockBorder: {
    borderTopWidth: 1,
    borderTopColor: '#3A4D5F',
  },
  statusInfo: {
    flex: 1,
  },
  statusLabel: {
    fontSize: 12,
    color: '#93A4B5',
    marginBottom: 2,
  },
  statusValueRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  dot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 8,
  },
  statusValue: {
    fontSize: 18,
    fontWeight: '800',
    color: '#EAF0F6',
  },
  statusButton: {
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 10,
    marginLeft: 10,
  },
  statusButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '700',
  },
  card: {
    backgroundColor: '#F4F6F8',
    borderRadius: 18,
    padding: 18,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '800',
    color: '#1F2D3A',
    marginBottom: 4,
  },
  sectionGap: {
    marginTop: 22,
  },
  inputLabel: {
    fontSize: 13,
    fontWeight: '600',
    color: '#4A5B6B',
    marginBottom: 4,
    marginTop: 10,
  },
  input: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#D5DDE5',
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 15,
    color: '#1A202C',
  },
  textArea: {
    height: 84,
    textAlignVertical: 'top',
  },
  row: {
    flexDirection: 'row',
    gap: 12,
  },
  flexItem: {
    flex: 1,
  },
  photoGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  actionsContainer: {
    marginTop: 18,
    gap: 6,
    alignItems: 'center',
  },
});