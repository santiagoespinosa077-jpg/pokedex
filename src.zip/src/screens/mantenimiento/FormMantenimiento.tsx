import { useEffect, useRef } from 'react';
import {
  View, Text, TextInput, TextInputProps, ScrollView, Image,
  StyleSheet, StatusBar, TouchableOpacity,
} from 'react-native';
import { BtnTouch } from '../../components/BtnTouch';
import { Fab } from '../../components/Fab';
import { StackScreenProps } from '@react-navigation/stack';
import { StackMantenimientoParams } from '../../navigator/MantenimientoStackNavigator';
import { useImagePicker } from '../../hooks/useImagePicker';
import { useMantenimientoForm, FormMantenimientoData } from '../../hooks/useMantenimientoForm';
import { siguienteEstadoMan, siguientePrioridad } from '../../interfaces/pandoraApiResponse';

interface Props extends StackScreenProps<StackMantenimientoParams, 'FormMantenimiento'> {};

type ImagenKey = 'imagen1' | 'imagen2' | 'imagen3' | 'imagen4';
const IMAGENES: ImagenKey[] = ['imagen1', 'imagen2', 'imagen3', 'imagen4'];

const C = {
  fondo: '#090d16',
  superficieInput: '#111827',
  bordeInput: 'rgba(255, 255, 255, 0.1)',
  acento: '#6366f1',
  textoPrincipal: '#f8fafc',
  textoSecundario: '#94a3b8',
  placeholder: '#475569',
  peligro: '#ef4444',
  tagBg: 'rgba(99, 102, 241, 0.15)',
};

export const FormMantenimiento = ( { route, navigation }: Props ) => {

  const {
    state, handleInputChange, handleSubmit, handleDelete, handleUpdate, handleUpdatePrioridad,
  } = useMantenimientoForm();
  const { image64, pickImage } = useImagePicker();
  const slotActual = useRef<ImagenKey>('imagen1');

  useEffect(() => {
    const m = route.params;
    handleInputChange('id_in', m.id_in);
    handleInputChange('solicitante', m.solicitante);
    handleInputChange('area', m.area);
    handleInputChange('ubicacion', m.ubicacion);
    handleInputChange('tipo_mantenimiento', m.tipo_mantenimiento);
    handleInputChange('equipo', m.equipo);
    handleInputChange('descripcion', m.descripcion);
    handleInputChange('prioridad', m.prioridad);
    handleInputChange('estado', m.estado);
    handleInputChange('observaciones', m.observaciones ?? '');
    IMAGENES.forEach((k) => handleInputChange(k, m[k] ?? ''));
  }, []);

  useEffect(() => {
    image64 && handleInputChange(slotActual.current, image64);
  }, [image64]);

  const elegirImagen = (key: ImagenKey) => {
    slotActual.current = key;
    pickImage();
  };

  const esNuevo = state.id_in === 0;
  const siguienteEstado = siguienteEstadoMan(state.estado);
  const nuevaPrioridad = siguientePrioridad(state.prioridad);

  const campo = (
    label: string,
    field: keyof FormMantenimientoData,
    placeholder: string,
    extra?: TextInputProps,
  ) => (
    <View style={styles.fieldGroup}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        style={[styles.input, extra?.multiline && styles.textArea]}
        value={String(state[field] ?? '')}
        onChangeText={(text) => handleInputChange(field, text)}
        placeholder={placeholder}
        placeholderTextColor={C.placeholder}
        {...extra}
      />
    </View>
  );

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" backgroundColor={C.fondo} />

      {/* Fab con wrapper sin colisión de eventos */}
      <View style={styles.fabWrapper} pointerEvents="box-none">
        <Fab
          title="→"
          color={C.acento}
          action={() => navigation.popToTop()}
          position="right"
        />
      </View>

      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* Encabezado */}
        <View style={styles.header}>
          <Text style={styles.title}>
            {esNuevo ? 'Nueva solicitud' : 'Editar solicitud'}
          </Text>
          <Text style={styles.subtitle}>
            Gestiona el estado y los detalles del mantenimiento
          </Text>

          {!esNuevo && state.estado && (
            <View style={styles.statusBadge}>
              <Text style={styles.statusText}>
                ESTADO ACTUAL: {String(state.estado).toUpperCase()}
              </Text>
            </View>
          )}
          {!esNuevo && state.prioridad && (
            <View style={styles.statusBadge}>
              <Text style={styles.statusText}>
                PRIORIDAD: {String(state.prioridad).toUpperCase()}
              </Text>
            </View>
          )}
        </View>

        {/* Formulario */}
        <View style={styles.form}>
          {campo('SOLICITANTE', 'solicitante', 'Nombre del solicitante')}
          {campo('ÁREA', 'area', 'Escribe el área')}
          {campo('UBICACIÓN', 'ubicacion', 'Escribe la ubicación')}
          {campo('TIPO DE MANTENIMIENTO', 'tipo_mantenimiento', 'Preventivo, correctivo...')}
          {campo('EQUIPO', 'equipo', 'Escribe el equipo')}
          {campo('DESCRIPCIÓN', 'descripcion', 'Describe el problema...', {
            multiline: true,
            textAlignVertical: 'top',
          })}
          {campo('OBSERVACIONES', 'observaciones', 'Observaciones...', {
            multiline: true,
            textAlignVertical: 'top',
          })}

          <View style={styles.fieldGroup}>
            <Text style={styles.label}>IMÁGENES</Text>
            <View style={styles.imagesGrid}>
              {IMAGENES.map((key) => (
                <TouchableOpacity
                  key={key}
                  activeOpacity={0.8}
                  onPress={() => elegirImagen(key)}
                  style={styles.imageSlot}
                >
                  {state[key] ? (
                    <Image
                      style={styles.image}
                      source={{ uri: `data:image/png;base64,${state[key]}` }}
                    />
                  ) : (
                    <Text style={styles.imagePlaceholderText}>+ Foto</Text>
                  )}
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* Grupo de Botones de Acción */}
          <View style={styles.buttonGroup}>
            <BtnTouch
              text={esNuevo ? 'Crear solicitud' : 'Actualizar solicitud'}
              color={C.acento}
              borderColor="transparent"
              borderWidth={0}
              onPress={async () => {
                await handleSubmit();
                navigation.popToTop();
              }}
            />

            {!esNuevo && (
              <>
                {siguienteEstado !== state.estado && (
                  <View style={styles.actionMargin}>
                    <BtnTouch
                      text={`${siguienteEstado}`}
                      color="transparent"
                      borderColor={C.acento}
                      borderWidth={1}
                      onPress={async () => {
                        await handleUpdate(siguienteEstado);
                        navigation.popToTop();
                      }}
                    />
                  </View>
                )}

                <View style={styles.actionMargin}>
                  <BtnTouch
                    text={`Prioridad: ${nuevaPrioridad}`}
                    color="transparent"
                    borderColor={C.acento}
                    borderWidth={1}
                    onPress={async () => {
                      await handleUpdatePrioridad(nuevaPrioridad);
                      navigation.popToTop();
                    }}
                  />
                </View>

                <View style={styles.actionMargin}>
                  <BtnTouch
                    text="Eliminar solicitud"
                    color="transparent"
                    borderColor={C.peligro}
                    borderWidth={1}
                    onPress={async () => {
                      await handleDelete();
                      navigation.popToTop();
                    }}
                  />
                </View>
              </>
            )}
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

export default FormMantenimiento;

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: C.fondo,
  },
  fabWrapper: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 99,
    elevation: 99,
  },
  content: {
    paddingHorizontal: 24,
    paddingTop: 80,
    paddingBottom: 40,
  },
  header: {
    marginBottom: 28,
  },
  title: {
    color: C.textoPrincipal,
    fontSize: 28,
    fontWeight: '800',
    letterSpacing: -0.5,
  },
  subtitle: {
    color: C.textoSecundario,
    fontSize: 14,
    marginTop: 4,
  },
  statusBadge: {
    alignSelf: 'flex-start',
    backgroundColor: C.tagBg,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
    marginTop: 12,
    borderWidth: 1,
    borderColor: 'rgba(99, 102, 241, 0.3)',
  },
  statusText: {
    color: C.acento,
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  form: {
    width: '100%',
  },
  fieldGroup: {
    marginBottom: 20,
  },
  label: {
    color: C.textoSecundario,
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1.2,
    marginBottom: 8,
  },
  input: {
    backgroundColor: C.superficieInput,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: C.bordeInput,
    color: C.textoPrincipal,
    fontSize: 15,
    height: 50,
    paddingHorizontal: 16,
  },
  textArea: {
    height: 110,
    paddingTop: 14,
    paddingBottom: 14,
  },
  imagesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  imageSlot: {
    width: '47%',
    aspectRatio: 1,
    margin: '1.5%',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: C.bordeInput,
    backgroundColor: C.superficieInput,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  imagePlaceholderText: {
    color: C.textoSecundario,
    fontSize: 12,
    fontWeight: '500',
  },
  buttonGroup: {
    marginTop: 16,
  },
  actionMargin: {
    marginTop: 12,
  },
});