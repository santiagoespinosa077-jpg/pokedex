import { useEffect, useState } from 'react';
import { View, Text, FlatList, RefreshControl, TouchableOpacity, StyleSheet } from 'react-native';
import { useNavigation, useIsFocused } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { UseMantenimientoApi } from '../../hooks/useMantenimientoApi';
import { MantenimientoCard } from '../../components/MantenimientoCard';
import { Fab } from '../../components/Fab';
import { StackMantenimientoParams } from '../../navigator/MantenimientoStackNavigator';
import {
  EstadoMan,
  colorEstado,
  nuevaMantenimiento,
} from '../interfaces/pandoraApiReponse';

type Filtro = 'Todos' | EstadoMan;
const filtros: Filtro[] = ['Todos', ...Object.values(EstadoMan)];

export const HomeMantenimiento = () => {
  const { isLoading, loadMantenimiento, listMantenimiento } = useMantenimientoApi();
  const [filtro, setFiltro] = useState<Filtro>('Todos');

  const focused = useIsFocused();
  const navigation = useNavigation<StackNavigationProp<StackMantenimientoParams>>();

  useEffect(() => {
    (!isLoading) && loadMantenimiento();
  }, [focused]);

  const contar = (estado: EstadoMan) =>
    listMantenimiento.filter((m) => m.estado === estado).length;

  const lista = (filtro === 'Todos')
    ? listMantenimiento
    : listMantenimiento.filter((m) => m.estado === filtro);

  return (
    <View style={styles.mainContainer}>
      <FlatList
        data={lista}
        keyExtractor={(item) => `#${item.id_in}`}
        contentContainerStyle={styles.listContent}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        ListHeaderComponent={(
          <View style={styles.header}>
            <Text style={styles.title}>Mantenimiento</Text>

            {/* Resumen: cuántas solicitudes hay en cada estado */}
            <View style={styles.summaryRow}>
              {Object.values(EstadoMan).map((estado) => (
                <View key={estado} style={styles.summaryItem}>
                  <Text style={[styles.summaryNumber, { color: colorEstado[estado] }]}>
                    {contar(estado)}
                  </Text>
                  <Text style={styles.summaryLabel}>{estado}</Text>
                </View>
              ))}
            </View>

            {/* Filtros por estado */}
            <View style={styles.filterRow}>
              {filtros.map((f) => {
                const activo = f === filtro;
                return (
                  <TouchableOpacity
                    key={f}
                    activeOpacity={0.8}
                    onPress={() => setFiltro(f)}
                    style={[styles.chip, activo && styles.chipActive]}
                  >
                    <Text style={[styles.chipText, activo && styles.chipTextActive]}>{f}</Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>
        )}
        ListEmptyComponent={(
          !isLoading ? (
            <View style={styles.empty}>
              <Text style={styles.emptyTitle}>No hay solicitudes</Text>
              <Text style={styles.emptyText}>
                Toca el botón + para registrar la primera.
              </Text>
            </View>
          ) : null
        )}
        refreshControl={(
          <RefreshControl
            refreshing={isLoading}
            onRefresh={loadMantenimiento}
            colors={['#E8A317', '#3B82C4', '#3FA672']}
            progressBackgroundColor="#243342"
          />
        )}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => <MantenimientoCard mantenimiento={item} />}
      />

      <Fab
        title="+"
        color="#E8A317"
        position="right"
        action={() => navigation.navigate('FormMantenimiento', nuevaMantenimiento())}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    backgroundColor: '#18222C',
  },
  listContent: {
    paddingHorizontal: 16,
    paddingTop: 24,
    paddingBottom: 100,
  },
  header: {
    marginBottom: 16,
  },
  title: {
    fontSize: 30,
    fontWeight: '800',
    color: '#EAF0F6',
    marginBottom: 14,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#243342',
    borderRadius: 14,
    paddingVertical: 12,
    paddingHorizontal: 8,
    marginBottom: 14,
  },
  summaryItem: {
    flex: 1,
    alignItems: 'center',
  },
  summaryNumber: {
    fontSize: 26,
    fontWeight: '800',
  },
  summaryLabel: {
    fontSize: 12,
    color: '#93A4B5',
    marginTop: 2,
  },
  filterRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  chip: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    borderWidth: 1.5,
    borderColor: '#3A4D5F',
  },
  chipActive: {
    backgroundColor: '#EAF0F6',
    borderColor: '#EAF0F6',
  },
  chipText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#C3D0DC',
  },
  chipTextActive: {
    color: '#18222C',
  },
  separator: {
    height: 10,
  },
  empty: {
    alignItems: 'center',
    paddingTop: 40,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#EAF0F6',
  },
  emptyText: {
    fontSize: 14,
    color: '#93A4B5',
    marginTop: 4,
    textAlign: 'center',
  },
});