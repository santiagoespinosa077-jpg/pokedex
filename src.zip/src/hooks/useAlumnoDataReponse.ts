import { useEffect, useState, useCallback } from "react";
import { AlumnoDataResponse } from "../interfaces/pandoraApiResponse";
import { useApiUrl } from './useApiUrl';

export const useAlumnoDataResponse = () => {
  const { apiUrl } = useApiUrl();
  const [ isLoading, setIsLoading ] = useState<boolean>(false);
  const [ data, setData ] = useState<AlumnoDataResponse>();

  const loadData = useCallback(async () => {
    setIsLoading(true);
    try {
      const resp = await fetch(`${apiUrl}/alumno/consultas/data`);
      if (!resp.ok) throw new Error(`Error ${resp.status}`);
      const json: AlumnoDataResponse = await resp.json();
      setData(json);
    } catch (error) {
      console.log(error);
    } finally {
      setIsLoading(false);
    }
  }, [apiUrl]);

  useEffect( () => {
    loadData();
  },[]);

  return { isLoading, data, loadData };

}