import { useState } from 'react';
import { cachasApi } from '../api/cachasApi';
import { MantenimientoResponse, FormMantenimientoData } from '../interfaces/mantenimientoResponse';

interface UseMantenimientoApi {
  isLoading:           boolean;
  listMantenimiento:   MantenimientoResponse[];
  loadMantenimiento:   () => Promise<void>;
  createMantenimiento: (data: FormMantenimientoData) => Promise<boolean>;
  updateMantenimiento: (data: FormMantenimientoData) => Promise<boolean>;
  deleteMantenimiento: (data: FormMantenimientoData) => Promise<boolean>;
}

const urlApi = "http://192.168.101.13:3000/mantenimiento";

// id_in lo genera la base de datos: no se manda en el body
const armarBody = (data: FormMantenimientoData) => ({
  solicitante:        data.solicitante,
  area:               data.area,
  ubicacion:          data.ubicacion,
  tipo_mantenimiento: data.tipo_mantenimiento,
  equipo:             data.equipo,
  descripcion:        data.descripcion,
  prioridad:          data.prioridad,
  fecha:              data.fecha,
  tecnico:            data.tecnico,
  estado:             data.estado,
  observaciones:      data.observaciones,
  imagen1:            data.imagen1,
  imagen2:            data.imagen2,
  imagen3:            data.imagen3,
  imagen4:            data.imagen4,
});

export const useMantenimientoApi = (): UseMantenimientoApi => {
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [listMantenimiento, setListMantenimiento] = useState<MantenimientoResponse[]>([]);

  const loadMantenimiento = async () => {
    setIsLoading(true);
    try {
      const response = await cachasApi.get<MantenimientoResponse[]>(urlApi);
      setListMantenimiento(response.data);
    } catch (e: any) {
      console.log('Error al cargar:', e.response?.status, e.response?.data ?? e.message);
    } finally {
      setIsLoading(false);
    }
  };

  const createMantenimiento = async (data: FormMantenimientoData) => {
    try {
      await cachasApi.post(urlApi, armarBody(data));
      return true;
    } catch (e: any) {
      console.log('Error al crear:', e.response?.status, e.response?.data ?? e.message);
      return false;
    }
  };

  const updateMantenimiento = async (data: FormMantenimientoData) => {
    try {
      await cachasApi.patch(`${urlApi}/${data.id_in}`, armarBody(data));
      return true;
    } catch (e: any) {
      console.log('Error al actualizar:', e.response?.status, e.response?.data ?? e.message);
      return false;
    }
  };

  const deleteMantenimiento = async (data: FormMantenimientoData) => {
    try {
      await cachasApi.delete(`${urlApi}/${data.id_in}`);
      return true;
    } catch (e: any) {
      console.log('Error al eliminar:', e.response?.status, e.response?.data ?? e.message);
      return false;
    }
  };

  return {
    isLoading,
    listMantenimiento,
    loadMantenimiento,
    createMantenimiento,
    updateMantenimiento,
    deleteMantenimiento,
  };
};