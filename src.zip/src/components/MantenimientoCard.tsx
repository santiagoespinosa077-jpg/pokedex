import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { StackMantenimientoParams } from '../navigator/MantenimientoStackNavigator';
import {
  MantenimientoResponse,
  colorEstado,
  colorPrioridad,
} from '../interfaces/mantenimientoResponse';

interface Props {
  mantenimiento: MantenimientoResponse;
}

export const MantenimientoCard = ({ mantenimiento }: Props) => {
  const navigation = useNavigation<StackNavigationProp<StackMantenimientoParams>>();
  const colorDelEstado = colorEstado[mantenimiento.estado] ?? '#8A97A6';
  const colorDePrioridad = colorPrioridad[mantenimiento.prioridad] ?? '#8A97A6';

  return (
    <TouchableOpacity
      activeOpacity={0.85}
      onPress={() => navigation.navigate('FormMantenimiento', { ...mantenimiento })}
      style={style.container}
    >
      {/* La franja de la izquierda muestra el estado de un vistazo */}
      <View style={[style.stripe, { backgroundColor: colorDelEstado }]} />

      <View style={style.body}>
        <View style={style.topRow}>
          <Text style={style.equipo} numberOfLines={1}>
            {mantenimiento.equipo}
          </Text>
          <Text style={[style.prioridad, { color: colorDePrioridad, borderColor: colorDePrioridad }]}>
            {mantenimiento.prioridad}
          </Text>
        </View>

        <Text style={style.tipo} numberOfLines={1}>
          {mantenimiento.tipo_mantenimiento}
        </Text>

        <Text style={style.lugar} numberOfLines={1}>
          {mantenimiento.area} · {mantenimiento.ubicacion}
        </Text>

        <View style={style.bottomRow}>
          <View style={style.estadoRow}>
            <View style={[style.dot, { backgroundColor: colorDelEstado }]} />
            <Text style={style.estadoText}>{mantenimiento.estado}</Text>
          </View>
          <Text style={style.fecha}>{String(mantenimiento.fecha).slice(0, 10)}</Text>
        </View>
      </View>

      {mantenimiento.imagen1 ? (
        <Image
          style={style.thumb}
          source={{ uri: `data:image/png;base64,${mantenimiento.imagen1}` }}
          resizeMode="cover"
        />
      ) : null}
    </TouchableOpacity>
  );
};

const style = StyleSheet.create({
  container: {
    flexDirection: 'row',
    backgroundColor: '#243342',
    borderRadius: 14,
    overflow: 'hidden',
    elevation: 3,
  },
  stripe: {
    width: 8,
  },
  body: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 14,
  },
  topRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  equipo: {
    flex: 1,
    fontSize: 18,
    fontWeight: '800',
    color: '#EAF0F6',
    marginRight: 8,
  },
  prioridad: {
    fontSize: 12,
    fontWeight: '700',
    borderWidth: 1.5,
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 1,
  },
  tipo: {
    fontSize: 14,
    color: '#C3D0DC',
    marginTop: 2,
  },
  lugar: {
    fontSize: 13,
    color: '#93A4B5',
    marginTop: 2,
  },
  bottomRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  estadoRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  dot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: 6,
  },
  estadoText: {
    fontSize: 13,
    fontWeight: '700',
    color: '#EAF0F6',
  },
  fecha: {
    fontSize: 12,
    color: '#93A4B5',
  },
  thumb: {
    width: 84,
    backgroundColor: '#1B2733',
  },
});